# Instruções de Implantação da Aplicação

Este documento fornece as instruções para implantar a aplicação Django + React em seu ambiente local.

## Pré-requisitos

Antes de começar, certifique-se de que você tem os seguintes softwares instalados:

- **Python 3.11 ou superior:** [https://www.python.org/downloads/](https://www.python.org/downloads/)
- **Node.js 22.x ou superior:** [https://nodejs.org/](https://nodejs.org/)
- **pnpm:** Após instalar o Node.js, instale o pnpm globalmente executando: `npm install -g pnpm`

## Passos para Implantação

Siga os passos abaixo para configurar e executar a aplicação.

### 1. Descompacte o Código-Fonte

- Descompacte o arquivo `application_code.zip` em um diretório de sua escolha.

### 2. Configuração do Backend (Django)

Navegue até o diretório raiz onde você descompactou os arquivos e execute os seguintes comandos no seu terminal:

```bash
# 1. Crie e ative um ambiente virtual
python3 -m venv venv
source venv/bin/activate  # No Windows, use `venv\Scripts\activate`

# 2. Instale as dependências do Python
pip install -r requirements.txt

# 3. Aplique as migrações do banco de dados
python3 manage.py makemigrations
python3 manage.py migrate

# 4. Inicie o servidor de desenvolvimento do Django
# A API estará disponível em http://localhost:8001
python3 manage.py runserver 8001
```

**Importante:** Mantenha este terminal em execução para que o backend continue funcionando.

### 3. Configuração do Frontend (React)

Abra um **novo terminal** e navegue até o diretório `frontend` dentro do projeto:

```bash
# 1. Navegue até o diretório do frontend
cd frontend

# 2. Instale as dependências do Node.js
pnpm install

# 3. Inicie o servidor de desenvolvimento do React
# A aplicação estará disponível em http://localhost:5173
pnpm run dev
```

### 4. Acessando a Aplicação

Após iniciar os dois servidores (backend e frontend), você poderá acessar a aplicação abrindo o seguinte endereço no seu navegador:

**URL:** `http://localhost:5173`

A interface do React irá carregar e se comunicará automaticamente com o backend Django que está rodando na porta 8001. Agora você pode testar a aplicação, adicionando e visualizando itens.

