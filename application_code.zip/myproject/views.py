from django.shortcuts import render
from django.http import HttpResponse
from django.conf import settings
import os

def index(request):
    try:
        with open(os.path.join(settings.BASE_DIR, 'myproject', 'static', 'index.html')) as f:
            return HttpResponse(f.read())
    except FileNotFoundError:
        return HttpResponse("Frontend não encontrado", status=404)
